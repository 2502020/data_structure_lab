
#include <iostream>
#include <string>
using namespace std;

class Medicine {
public:
    string name;
    int medicineID;
    string expiryDate;

    Medicine* left;
    Medicine* right;

    Medicine(string n, int id, string date) {
        name = n;
        medicineID = id;
        expiryDate = date;

        left = NULL;
        right = NULL;
    }
};

class MinHeap {
private:
    Medicine* heap[100];
    int size;

    // Heapify Up
    void heapifyUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;

            if (heap[index]->expiryDate <
                heap[parent]->expiryDate) {

                swap(heap[index], heap[parent]);
                index = parent;
            }
            else {
                break;
            }
        }
    }

    // Heapify Down
    void heapifyDown(int index) {
        while (true) {
            int smallest = index;

            int left = 2 * index + 1;
            int right = 2 * index + 2;

            if (left < size &&
                heap[left]->expiryDate <
                heap[smallest]->expiryDate) {

                smallest = left;
            }

            if (right < size &&
                heap[right]->expiryDate <
                heap[smallest]->expiryDate) {

                smallest = right;
            }

            if (smallest != index) {
                swap(heap[index], heap[smallest]);
                index = smallest;
            }
            else {
                break;
            }
        }
    }

    // Update left and right pointers
    void updatePointers() {
        for (int i = 0; i < size; i++) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < size)
                heap[i]->left = heap[left];
            else
                heap[i]->left = NULL;

            if (right < size)
                heap[i]->right = heap[right];
            else
                heap[i]->right = NULL;
        }
    }

public:
    MinHeap() {
        size = 0;
    }

    // Insert Medicine
    void insert(string name, int id, string date) {
        Medicine* newMedicine =
            new Medicine(name, id, date);

        heap[size] = newMedicine;
        size++;

        heapifyUp(size - 1);
        updatePointers();
    }

    // Level Order Traversal
    void display() {
        cout << "\nMedicine Heap:\n";

        for (int i = 0; i < size; i++) {
            cout << "Name: " << heap[i]->name
                 << " | ID: " << heap[i]->medicineID
                 << " | Expiry Date: "
                 << heap[i]->expiryDate << endl;
        }
    }

    // Display nearest expiry medicine
    void nearestExpiry() {
        if (size == 0) {
            cout << "\nNo medicines available.\n";
            return;
        }

        cout << "\nMedicine to be checked first:\n";

        cout << "Name: " << heap[0]->name
             << " | ID: " << heap[0]->medicineID
             << " | Expiry Date: "
             << heap[0]->expiryDate << endl;
    }

    // Delete medicine with nearest expiry
    void deleteNearestExpiry() {
        if (size == 0) {
            cout << "\nNo medicine to delete.\n";
            return;
        }

        cout << "\nMedicine removed: "
             << heap[0]->name
             << " | Expiry Date: "
             << heap[0]->expiryDate << endl;

        delete heap[0];

        heap[0] = heap[size - 1];
        size--;

        if (size > 0) {
            heapifyDown(0);
        }

        updatePointers();
    }

    // Destructor
    ~MinHeap() {
        for (int i = 0; i < size; i++) {
            delete heap[i];
        }
    }
};

int main() {
    MinHeap h;

    // Insert six medicines
    h.insert("Panadol", 101, "2027-05-10");
    h.insert("Brufen", 102, "2026-12-15");
    h.insert("Augmentin", 103, "2027-02-20");
    h.insert("Calpol", 104, "2026-11-30");
    h.insert("Disprin", 105, "2027-08-25");
    h.insert("Flagyl", 106, "2026-10-20");

    // Display all medicines
    cout << "BEFORE REMOVAL";
    h.display();

    // Identify nearest expiry
    h.nearestExpiry();

    // Remove medicine with nearest expiry
    h.deleteNearestExpiry();

    // Display updated heap
    cout << "\nAFTER REMOVAL";
    h.display();

    // Display next medicine
    h.nearestExpiry();

    return 0;
}

